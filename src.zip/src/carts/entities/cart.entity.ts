import {
  Column,
  Entity,
  OneToMany,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Client } from '../../users/entities/client.entity';
import { OrderItem } from './order-item.entity';

@Entity()
export class Cart {
  @PrimaryGeneratedColumn()
  cartId: number;

  @Column({ default: 0, type: 'decimal', precision: 10, scale: 2 })
  totalPrice: number;

  @OneToMany(() => OrderItem, (orderItem) => orderItem.cart, {
    eager: true,
    cascade: true,
  })
  orderItems: OrderItem[];

  @OneToOne(() => Client, (client) => client.cart)
  client: Client;
}
